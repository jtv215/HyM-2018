<?php
session_start();
?>
<html>
	<head>
		<title>.: RLPHP :.</title>
		<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	</head>
	<body>
	<?php include "php/navbar.php"; ?>
	<div class="container">
	<div class="row">
	<div class="col-md-12">
			<h2>REGISTRO Y LOGIN BASICO</h2>
			<p class="lead">Sistema de Registro y Login Sencillo con PHP y MySQL</p>
			<p>Les presento un sistema de registro y login sencillo.</p>
			<p>Puede realizar lo siguiente: </p>
			<ol>
				<li>Registrate en la opcion de registro.</li>
				<li>Inicie sesion en la opcion de login.</li>
				<li>Compruebe el listado de usuarios si es administrador. </li>
				<li>Para finalizar la sesion, click en la opcion salir .</li>
			</ol>
			<br>
	</div>
	</div>
	</div>
	</body>
</html>
